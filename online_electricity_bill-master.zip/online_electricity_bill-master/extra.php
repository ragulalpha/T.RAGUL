$feed='UPDATE login
SET `feedback` = " '.$feedback. '" WHERE username = "' . $_SESSION['user'] . '"';